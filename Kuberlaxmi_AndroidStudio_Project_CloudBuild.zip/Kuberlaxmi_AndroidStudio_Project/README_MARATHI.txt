KUBERLAXMI ANDROID STUDIO PROJECT

हा प्रोजेक्ट Android Studio मध्ये उघडण्यासाठी:
1. ZIP extract करा.
2. Android Studio > Open > Kuberlaxmi_AndroidStudio_Project फोल्डर निवडा.
3. Gradle Sync होऊ द्या (इंटरनेट लागेल).
4. Android फोन USB ने जोडून Developer Options > USB debugging सुरू करा.
5. Run (हिरवा त्रिकोण) दाबा.
6. APK बनवण्यासाठी Build > Build APK(s) निवडा.

प्रोजेक्टमध्ये मूळ वेबसाइटचे index.html, app.js आणि styles.css Android WebView मध्ये bundle केले आहेत.
नेटवर्कवर चालणाऱ्या सेवांसाठी Internet लागेल. मूळ वेबसाइटमधील backend/remote sync सेटिंग्ज स्वतंत्रपणे तपासाव्या लागतील.


CLOUD APK BUILD (PC न वापरता, GitHub मोबाइलवरून):
1. ZIP मधील फोल्डर GitHub repository मध्ये upload करा.
2. Repository > Actions > Build Kuberlaxmi APK workflow निवडा.
3. Run workflow दाबा (किंवा main/master branch वर upload केल्यास workflow आपोआप चालू होईल).
4. Build पूर्ण झाल्यावर workflow run च्या Artifacts विभागातून Kuberlaxmi-debug-apk डाउनलोड करा.
